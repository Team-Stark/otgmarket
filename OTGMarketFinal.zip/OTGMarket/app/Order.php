<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Darryldecode\Cart\Facades\CartFacade;

class Order extends Model
{
    protected $fillable=['total','delivered', 'in_progress', 'driver_id', 'address_id'];

    public function orderItems()
    {
    	return $this->belongsToMany(Item::class)->withPivot('quantity','total', 'added');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public static function createOrder($address_id)
    {
    	$user=Auth::user();
        $order=$user->orders()->create([
            'total' => CartFacade::getTotal()*1.4,
            'delivered' => 0,
            'in_progress' => 0,
            'address_id' => $address_id,
        ]);

        $cartItems=CartFacade::getContent();
        foreach ($cartItems as $cartItem){
            $order->orderItems()->attach($cartItem->id,[
                'quantity'=>$cartItem->quantity,
                'total'=>$cartItem->quantity*$cartItem->price,
                'added'=>0
            ]);
        }
        CartFacade::clear();
    }

    public function address()
    {
        return $this->hasOne('App\Address', 'id');
    }
}
