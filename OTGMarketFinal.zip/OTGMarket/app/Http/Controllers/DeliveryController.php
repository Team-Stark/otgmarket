<?php

namespace App\Http\Controllers;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use App\Order;
use Auth;

class DeliveryController extends Controller
{

	public function availableorders()
	{
		$orders = Order::where(['in_progress' => 0, 'delivered' => 0])->get();
		return view('front.availableorders')->with('orders', $orders);
	}

	public function updateavailable(Request $request)
	{
		$accepted = $request->input('order');
		Order::where('id', $accepted)->update(['in_progress' => 1, 'driver_id' => Auth::id()]);
		return back();
	}

	public function orders()
	{
		$inprogress = Order::where('driver_id', Auth::id())->where('delivered', 0)->get();
		return view('front.pendingorders')->with('inprogress', $inprogress);
	}

	public function workorder($orderID)
	{
		$orderitems = Order::where('id', $orderID)->first()->orderItems()->get();
		$address = Order::where('id', $orderID)->first()->address()->first();
		return view('front.workorder')->with('orderitems', $orderitems)->with('orderID', $orderID)->with('address', $address);
	}

	public function ItemUpdate(Request $request, $orderID)
	{
		$itemPurchased = $request->input('itemPurchased');
		$allItems = true;
		$orderitems = Order::where('id', $orderID)->first()->orderItems();
		foreach($itemPurchased as $check)
		{
			$orderitems->updateExistingPivot($check, ['added' => 1]);
		}

		if($orderitems->where('added', 0)->exists())
			$allItems = false;

		if($allItems)
		{
			$orders = Order::where('id', $orderID)->get();
			foreach($orders as $order)
			{
				$order->delivered = 1;
				$order->update();
				$order->in_progress = 0;
				$order->update();
			}
			return redirect('/availableorders');
		}
		else
			return back();
	}
}
