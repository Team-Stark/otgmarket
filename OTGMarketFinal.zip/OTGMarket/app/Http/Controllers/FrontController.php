<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Item;
use App\Order;
use Illuminate\Support\Facades\Auth;

class FrontController extends Controller
{
    public function index()
    {
      $randoms = Item::all()->random(4);
    	return view('front.home', compact('randoms'));
    }

    public function results(Request $request)
    {
      $s = $request->input('s');
      $results = Item::latest()->search($s)->paginate(20);
    	return view('front.results', compact('results'));
    }

    public function item()
    {
    	return view('front.item');
    }

    public function availableorders()
   {
       $products = [ 'Bread', 'Milk', 'Eggs' ];
       return view('front.availableorders')->withProducts($products);
   }

   public function orderdetails()
   {
        $products = ['Bread', 'Milk', 'Eggs'];
        $details = ['John Doe','1234 Main Street, Tallahassee, Fl, 32301', $products];
        
        return view('front.orderdetails')->withDetails($details);
   }

   public function myorders()
 {
     $user=Auth::user();
     $orders = $user->orders()->get();
     return view('front.myorders', compact('orders'));
 }

  public function orderlist()
  {
      $details = ['John Doe','1234 Main Street, Tallahassee, FL, 32301'];
      $products = [ $details, 'Bread', 'Milk', 'Eggs' ];
      return view('front.orderlist')->withProducts($products);
  }

  public function settings()
   {
      if(Auth::check())
      {
        $user = Auth::user();
        return view('account.settings', ["user" => $user]);
      }
      else
        return redirect('/login');
   }

   public function updatesettings(Request $request)
   {
    $user = Auth::user();
    if(!empty($request->input('name')))
      $user->name = $request->input('name');
    if(!empty($request->input('email')))
      $user->email = $request->input('email');
    $user->save();
    return redirect('settings');
   }

   public function contact()
   {
    return view('front.contact');
   }
}
