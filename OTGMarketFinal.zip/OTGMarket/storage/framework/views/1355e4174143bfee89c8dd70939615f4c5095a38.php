<?php $__env->startSection('title', 'Available Orders'); ?>

<?php $__env->startSection('content'); ?>

    <h1 class="text-center" style="margin-top:40px">Available Orders:</h1>
    <table style="margin-left:400px; margin-top:100px; margin-bottom:300px;">
        <tr>
            <th></th>
        </tr>
        <?php if($orders->isEmpty()): ?>
            <h6 class="text-center" style="margin-top:60px;">There aren't any available orders in your area :(</h6>
        <?php endif; ?>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <a style="margin-left:260px;">Service Charge: $<?php echo e(($order->total)*.4); ?> | Item Count: <?php echo e(count($order->orderItems()->get())); ?> | <?php echo e($order->address()->first()->addressline); ?>, <?php echo e($order->address()->first()->city); ?></a>
            </td>
            <td>
                <form method="get" action="<?php echo e(route('updateavailable')); ?>">
                    <button name="order" type="submit" value="<?php echo e($order->id); ?>" style="margin-left:20px; margin-bottom:-7px;">Accept Order</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>