<?php $__env->startSection('title', 'Your Work Orders'); ?>

<?php $__env->startSection('content'); ?>

	<h1 class="text-center" style="margin-top:50px; margin-bottom:100px;">Your Work Orders:</h1>
	<?php $__currentLoopData = $inprogress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<a href="<?php echo e(route('/workorder', [$order->id])); ?>" style="margin-left:775px">Order Number: <?php echo e($order->id); ?></a>
	<br>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>