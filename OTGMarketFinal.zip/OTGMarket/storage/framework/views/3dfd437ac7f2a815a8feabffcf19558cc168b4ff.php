<?php $__env->startSection('title', 'Results'); ?>

<?php $__env->startSection('content'); ?>
		<h1 class="text-center" style="margin-top:50px; margin-bottom:50px;">Here's what we found:</h1>
		<?php if($results->isEmpty()): ?>
			<h6 class="text-center" style="margin-top:60px;">Sorry, No Matching Items Found :(</h6>
		<?php else: ?>
		<div class="grid">
			<div class="row" style="margin-bottom:30px;">
				<?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="colspan-2 offset-1">
					<a href="<?php echo e(route('cart.edit',$item->id)); ?>">
						<div data-role="tile" data-size="medium" data-cover="<?php echo e(url('images',$item->image)); ?>">
							<span class="branding-bar fg-dark">Add to Cart</span>
						</div>
					</a>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<div class="row">
				<?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="colspan-2 offset-1">
					<h5><?php echo e($item->name); ?> <br>$<?php echo e(number_format($item->price, 2, '.', '')); ?></h5>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
		<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>