<?php $__env->startSection('content'); ?>

	<h1 class="text-center" style="margin-top:30px; margin-bottom:30px;">Cart Items</h1>
	<table class="table table-hover">
		<thead>
			<tr>
				<th>Name</th>
				<th>Price</th>
				<th>Quantity</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($cartItem->name); ?></td>
				<td>$<?php echo e($cartItem->price); ?></td>
				<td width="50px">
					<?php echo Form::open(['route' => ['cart.update',$cartItem->id], 'method' => 'PUT' ]); ?>

						<input name="quantity" type="text" value="<?php echo e($cartItem->quantity); ?>" width="30px">
						<input type="submit" class="btn btn-sm btn-default" value="Ok">
					<?php echo Form::close(); ?>

				</td>
				<td>
					<form action="<?php echo e(route('cart.destroy', $cartItem->id)); ?>" method="POST">
						<?php echo e(csrf_field()); ?>

						<?php echo e(method_field('DELETE')); ?>

						<input class="button" type="submit" value="Delete">
					</form>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			<tr>
				<td></td>
				<td>Subtotal: $<?php echo e(number_format(Cart::getTotal(), 2, '.', '')); ?><br>
					Service Charge: $<?php echo e(number_format(Cart::getTotal()*.4, 2, '.', '')); ?><br>
					Grand Total: $<?php echo e(number_format(Cart::getTotal()*1.4, 2, '.', '')); ?></td>
				<td>Items: <?php echo e(Cart::getTotalQuantity()); ?></td>
			</tr>
		</tbody>
	</table>

<div style="text-align:center; margin-top:50px; margin-bottom:50px;">
	<a href="<?php echo e(route('checkout.shipping')); ?>" class="button">Checkout</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>