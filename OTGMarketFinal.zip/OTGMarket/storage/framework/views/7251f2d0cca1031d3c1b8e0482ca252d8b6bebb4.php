<?php $__env->startSection('title', 'Current Order'); ?>

<?php $__env->startSection('content'); ?>


<style>
/* The container */
.container {
    display: block;
    position: relative;
    padding-left: 35px;
    margin-bottom: 12px;
    cursor: pointer;
    font-size: 22px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}

/* Hide the browser's default checkbox */
.container input {
    position: absolute;
    opacity: 0;
    cursor: pointer;
    height: 0;
    width: 0;
}

/* Create a custom checkbox */
.checkmark {
    position: absolute;
    top: 0;
    left: 0;
    height: 25px;
    width: 25px;
    background-color: #eee;
}

/* On mouse-over, add a grey background color */
.container:hover input ~ .checkmark {
    background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.container input:checked ~ .checkmark {
    background-color: #2196F3;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
    content: "";
    position: absolute;
    display: none;
}

/* Show the checkmark when checked */
.container input:checked ~ .checkmark:after {
    display: block;
}

/* Style the checkmark/indicator */
.container .checkmark:after {
    left: 9px;
    top: 5px;
    width: 5px;
    height: 10px;
    border: solid white;
    border-width: 0 3px 3px 0;
    -webkit-transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    transform: rotate(45deg);
}
</style>

<h1 class="text-center" style="margin-top:50px">Order:</h1>
<br>
<h4 class="text-center"><?php echo e($address->addressline); ?> <?php echo e($address->city); ?> <?php echo e($address->state); ?> <?php echo e($address->zip); ?></h4>
<div style="align-items:center; margin-bottom:50px;">
<table style="margin-left:720px">
	<tr style="margin-top:15px">
s	</tr>
	<tr style="margin-top:30px">
<form action="<?php echo e(route('itemupdate', [$orderID])); ?>" method="get">
	<?php $__currentLoopData = $orderitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<td><?php echo e($item->name); ?> <br>Quantity: <?php echo e($item->pivot->quantity); ?></td> 
	<td>
		<div data-role="tile" data-size="medium" data-cover="<?php echo e(url('images',$item->image)); ?>">
		</div>
	</td> 
	<td>
		<label class="container" style="margin-left:10px; margin-bottom:90px;">
		<input type="checkbox" name="itemPurchased[]" value="<?php echo e($item->id); ?>" <?php echo e($item->pivot->added==1?"checked":""); ?>>

                <span class="checkmark"></span>
                </label>
	</td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
<div style="align-items:center; margin-top:30px; margin-bottom:100px;">
	<button  style="margin-left:785px; margin-top:30px; margin-bottom:50px" type="submit">Update Order</button>
</div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>