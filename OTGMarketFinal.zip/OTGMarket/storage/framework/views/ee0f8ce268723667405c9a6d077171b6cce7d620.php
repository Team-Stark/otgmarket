<?php $__env->startSection('title', 'Contact Us'); ?>

<?php $__env->startSection('content'); ?>

        <h1 class="text-center" style="margin-top:50px; margin-bottom:50px;">Contact Us</h1>
        
        <h4 class="text-center" style="margin-bottom:50px;">Questions? Comments? Concerns? Contact us by phone or email, we'll help you out.</h4>

        <hr>

        <p class="text-center">Phone: <a href="tel:1-850-867-5309">(850) 867-5309</a></p>
        <p class="text-center" style="margin-bottom:100px;">Email: <a href="mailto:webmaster@otgmarket.com?subject=Contact Us">webmaster@otgmarket.com</a></p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>