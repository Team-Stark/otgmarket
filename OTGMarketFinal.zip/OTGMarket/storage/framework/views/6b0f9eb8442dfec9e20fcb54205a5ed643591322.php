<?php $__env->startSection('content'); ?>

<div style="text-align: center; display: block; margin: auto; margin-top:50px;">
<form method="POST" action="<?php echo e(url('updatesettings')); ?>">
	<?php echo csrf_field(); ?>
	<h1>Current Account Details</h1>
	<br>
	<b>Name:</b>
	<br>
	<i><?php echo e($user->name); ?></i>
	<br>
	<b>Email:</b>
	<br>
	<i><?php echo e($user->email); ?></i>
	<br>
	<b>Role:</b>
	<br>
	<i><?php echo e($user->role); ?></i>
	<br>
	<br>
	<br>
	Name
	<input type="text" name="name" style="width: 30%; margin: 0 auto;">
	<br>
	Email
	<input type="email" name="email" style="width: 30%; margin: 0 auto;">
	<br>
	<input type="submit">
	<br>
	<a class="button" href="<?php echo e(url('/logout')); ?>" style="margin-top:30px; margin-bottom:30px;">Logout</a>
</form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>