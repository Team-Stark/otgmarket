<?php $__env->startSection('content'); ?>

<h1 class="text-center" style="margin-top:50px; margin-bottom:50px;">What item are you looking for?</h1>
		<div class="grid" style="margin-bottom:100px">
			<div class="row" style="margin-bottom:50px;">
				<div class="cell-5 offset-3" style="margin-left:500px; margin-top:50px">
					<form action="<?php echo e(route('results')); ?>" method="get" class="form-inline">
				      <div class="form-group">
				        <input type="text" class="form-control" name="s" placeholder="Item">
				      </div>
				      <div class="form-group">
				        <button class="btn btn-success" style="margin-right:0px;" type="submit">Search</button>
				      </div>
				    </form>
				</div>
			</div>
		</div>

		<h2 class="text-center" style="margin-bottom:40px;">Random items you might enjoy:</h1>
		<div class="grid" >
			<div class="row" style="margin-bottom:30px; ext-align:center;">
				<?php $__currentLoopData = $randoms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="colspan-2 offset-1">
					<a href="<?php echo e(route('cart.edit',$item->id)); ?>">
						<div data-role="tile" data-size="medium" data-cover="<?php echo e(url('images',$item->image)); ?>">
							<span class="branding-bar fg-dark">Add to Cart</span>
						</div>
					</a>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<div class="row" style="margin-bottom:100px;">
				<?php $__currentLoopData = $randoms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="colspan-2 offset-1">
					<h5><?php echo e($item->name); ?> <br>$<?php echo e(number_format($item->price, 2, '.', '')); ?></h5>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>