@extends('layout.main')

@section('content')

<div style="text-align: center; display: block; margin: auto; margin-top:50px;">
<form method="POST" action="{{ url('updatesettings') }}">
	@csrf
	<h1>Current Account Details</h1>
	<br>
	<b>Name:</b>
	<br>
	<i>{{ $user->name }}</i>
	<br>
	<b>Email:</b>
	<br>
	<i>{{ $user->email }}</i>
	<br>
	<b>Role:</b>
	<br>
	<i>{{ $user->role }}</i>
	<br>
	<br>
	<br>
	Name
	<input type="text" name="name" style="width: 30%; margin: 0 auto;">
	<br>
	Email
	<input type="email" name="email" style="width: 30%; margin: 0 auto;">
	<br>
	<input type="submit">
	<br>
	<a class="button" href="{{url('/logout') }}" style="margin-top:30px; margin-bottom:30px;">Logout</a>
</form>
</div>

@endsection