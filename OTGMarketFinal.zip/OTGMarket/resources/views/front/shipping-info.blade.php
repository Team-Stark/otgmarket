@extends('layout.main')

@section('content')

	<h1 class="text-center" style="margin-top:50px; margin-bottom:50px;">Where should we bring your groceries?</h1>

	{!! Form::open(['route' => 'address.store', 'method' => 'post']) !!}

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		{{ Form::label('addressline', 'Address Line') }}
		{{ Form::text('addressline', null, array('class' => 'form-control')) }}
	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		{{ Form::label('city', 'City') }}
		{{ Form::text('city', null, array('class' => 'form-control')) }}
	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		{{ Form::label('state', 'State') }}
		{{ Form::text('state', null, array('class' => 'form-control')) }}
	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		{{ Form::label('zip', 'Zip') }}
		{{ Form::text('zip', null, array('class' => 'form-control')) }}
	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		{{ Form::label('country', 'Country') }}
		{{ Form::text('country', null, array('class' => 'form-control')) }}
	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px; margin-bottom:50px;">
		{{ Form::label('phone', 'Phone') }}
		{{ Form::text('phone', null, array('class' => 'form-control')) }}
	</div>

	<hr>

		<h1 class="text-center" style="margin-top:50px; margin-bottom:50px;">We'll need some payment info:</h1>

	

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		{{ Form::label('cardnumber', 'Card Number') }}
		{{ Form::text('cardnumber', null, array('class' => 'form-control')) }}
	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		{{ Form::label('expiration', 'Expiration (mm/yy)') }}
		{{ Form::text('expiration', null, array('class' => 'form-control')) }}
	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		{{ Form::label('cvv', 'CVV') }}
		{{ Form::text('cvv', null, array('class' => 'form-control')) }}
	</div>

<div style="text-align:center; margin-top:50px; margin-bottom:50px;">

	{{ Form::submit('Submit Order', array('class' => 'button success')) }}
	{!! Form::close() !!}

</div>

@endsection