@extends('layout.main')

@section('title', 'Available Orders')

@section('content')

    <h1 class="text-center" style="margin-top:40px">Available Orders:</h1>
    <table style="margin-left:400px; margin-top:100px; margin-bottom:300px;">
        <tr>
            <th></th>
        </tr>
        @if($orders->isEmpty())
            <h6 class="text-center" style="margin-top:60px;">There aren't any available orders in your area :(</h6>
        @endif
        @foreach($orders as $order)
        <tr>
            <td>
                <a style="margin-left:260px;">Service Charge: ${{($order->total)*.4}} | Item Count: {{count($order->orderItems()->get())}} | {{$order->address()->first()->addressline}}, {{$order->address()->first()->city}}</a>
            </td>
            <td>
                <form method="get" action="{{ route('updateavailable') }}">
                    <button name="order" type="submit" value="{{ $order->id }}" style="margin-left:20px; margin-bottom:-7px;">Accept Order</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>

@endsection