@extends('layout.main')

@section('title', 'Your Work Orders')

@section('content')

	<h1 class="text-center" style="margin-top:50px; margin-bottom:100px;">Your Work Orders:</h1>
	@foreach($inprogress as $order)
	<a href="{{ route('/workorder', [$order->id]) }}" style="margin-left:775px">Order Number: {{ $order->id }}</a>
	<br>
	@endforeach

@endsection