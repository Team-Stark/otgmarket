@extends('layout.main')

@section('title', 'Results')

@section('content')
		<h1 class="text-center" style="margin-top:50px; margin-bottom:50px;">Here's what we found:</h1>
		@if($results->isEmpty())
			<h6 class="text-center" style="margin-top:60px;">Sorry, No Matching Items Found :(</h6>
		@else
		<div class="grid">
			<div class="row" style="margin-bottom:30px;">
				@foreach($results as $item)
				<div class="colspan-2 offset-1">
					<a href="{{route('cart.edit',$item->id)}}">
						<div data-role="tile" data-size="medium" data-cover="{{url('images',$item->image)}}">
							<span class="branding-bar fg-dark">Add to Cart</span>
						</div>
					</a>
				</div>
				@endforeach
			</div>
			<div class="row">
				@foreach($results as $item)
				<div class="colspan-2 offset-1">
					<h5>{{$item->name}} <br>${{number_format($item->price, 2, '.', '')}}</h5>
				</div>
				@endforeach
			</div>
		</div>
		@endif

@endsection