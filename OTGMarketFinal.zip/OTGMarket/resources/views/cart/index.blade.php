@extends('layout.main')

@section('content')

	<h1 class="text-center" style="margin-top:30px; margin-bottom:30px;">Cart Items</h1>
	<table class="table table-hover">
		<thead>
			<tr>
				<th>Name</th>
				<th>Price</th>
				<th>Quantity</th>
			</tr>
		</thead>
		<tbody>
			@foreach($items as $cartItem)
			<tr>
				<td>{{$cartItem->name}}</td>
				<td>${{$cartItem->price}}</td>
				<td width="50px">
					{!! Form::open(['route' => ['cart.update',$cartItem->id], 'method' => 'PUT' ]) !!}
						<input name="quantity" type="text" value="{{$cartItem->quantity}}" width="30px">
						<input type="submit" class="btn btn-sm btn-default" value="Ok">
					{!! Form::close() !!}
				</td>
				<td>
					<form action="{{route('cart.destroy', $cartItem->id)}}" method="POST">
						{{csrf_field()}}
						{{method_field('DELETE')}}
						<input class="button" type="submit" value="Delete">
					</form>
				</td>
			</tr>
			@endforeach

			<tr>
				<td></td>
				<td>Subtotal: ${{number_format(Cart::getTotal(), 2, '.', '')}}<br>
					Service Charge: ${{number_format(Cart::getTotal()*.4, 2, '.', '')}}<br>
					Grand Total: ${{number_format(Cart::getTotal()*1.4, 2, '.', '')}}</td>
				<td>Items: {{Cart::getTotalQuantity()}}</td>
			</tr>
		</tbody>
	</table>

<div style="text-align:center; margin-top:50px; margin-bottom:50px;">
	<a href="{{route('checkout.shipping')}}" class="button">Checkout</a>
</div>
@endsection