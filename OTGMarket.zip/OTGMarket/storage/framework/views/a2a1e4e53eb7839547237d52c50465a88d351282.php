<?php $__env->startSection('title', 'shirt'); ?>

<?php $__env->startSection('content'); ?>

<h2 class="text-center" style="margin-top:50px;">Publix Lettuce $1.50</h2>
		<div class="row">
			<div class="colspan-3 offset-4">
				<img src="plettuce.jpg" style="width:300px;height:300px;">
			</div>
		</div>
		<div class="row" style="margin-top:30px;">
			<div class="colspan-1 offset-3">
				<p style="margin-right: 15px;">Quantity: </p>
			</div>
			<div class="colspan-3">
				<input type="text" data-role="spinner" data-buttons-position="right" data-min-value="0" data-max-value="99" data-default-value="0">
			</div>
			<div class="colspan-3">
				<button class="button primary large" style="margin-left:25px;">Add to Cart</button>
			</div>
		</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>