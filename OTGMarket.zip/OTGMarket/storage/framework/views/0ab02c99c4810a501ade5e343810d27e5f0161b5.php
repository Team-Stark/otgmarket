<?php $__env->startSection('content'); ?>

<h1 class="text-center" style="margin-top:50px; margin-bottom:50px;">What item are you looking for?</h1>
		<div class="grid">
			<div class="row" style="margin-bottom:50px;">
				<div class="cell-3 offset-2">
					<select data-role="select" data-prepend="Store: ">
						<option>Publix</option>
						<option>Walmart</option>
						<option>Lucky's</option>
					</select>
				</div>
				<div class="cell-5">
					<form>
						<a href="<?php echo e(url('/results')); ?>">
							<input type="text" data-role="input" data-search-button="true" data-prepend="Item: ">
						</a>
					</form>
				</div>
			</div>
		</div>
		<!-- Need to make the images and names in these generate from something -->
		<h2 class="text-center" style="margin-bottom:30px;">Hot Items In Your Area</h2>
		<div class="grid">
			<div class="row" style="margin-bottom:30px;">
				<div class="colspan-2 offset-2">
					<a href="<?php echo e(route('item')); ?>">
						<div data-role="tile" data-size="medium" data-cover="lettuce.jpg"></div>
					</a>
				</div>
				<div class="colspan-2">
					<a href="<?php echo e(route('item')); ?>">
						<div data-role="tile" data-size="medium" data-cover="cereal.jpg"></div>
					</a>
				</div>
				<div class="colspan-2">
					<a href="<?php echo e(route('item')); ?>">
						<div data-role="tile" data-size="medium" data-cover="milk.jpg"></div>
					</a>
				</div>
				<div class="colspan-2">
					<a href="<?php echo e(route('item')); ?>">
						<div data-role="tile" data-size="medium" data-cover="eggs.jpg"></div>
					</a>
				</div>
			</div>
			<div class="row" style="margin-bottom:50px;">
				<div class="colspan-2 offset-2">
					<h5>Lettuce $1.50</h5>
				</div>
				<div class="colspan-2">
					<h5>Cereal $4</h5>
				</div>
				<div class="colspan-2">
					<h5>Milk $3</h5>
				</div>
				<div class="colspan-2">
					<h5>Publix Large Eggs 6-Count $2</h5>
				</div>
			</div>
		</div>
		<h2 class="text-center" style="margin-bottom:30px;">Recently Bought</h2>
		<div class="grid">
			<div class="row" style="margin-bottom:30px;">
				<div class="colspan-2 offset-2">
					<a href="<?php echo e(route('item')); ?>">
						<div data-role="tile" data-size="medium" data-cover="lettuce.jpg"></div>
					</a>
				</div>
				<div class="colspan-2">
					<a href="<?php echo e(route('item')); ?>">
						<div data-role="tile" data-size="medium" data-cover="cereal.jpg"></div>
					</a>
				</div>
				<div class="colspan-2">
					<a href="<?php echo e(route('item')); ?>">
						<div data-role="tile" data-size="medium" data-cover="milk.jpg"></div>
					</a>
				</div>
				<div class="colspan-2">
					<a href="<?php echo e(route('item')); ?>">
						<div data-role="tile" data-size="medium" data-cover="eggs.jpg"></div>
					</a>
				</div>
			</div>
			<div class="row" style="margin-bottom:50px;">
				<div class="colspan-2 offset-2">
					<h5>Lettuce $1.50</h5>
				</div>
				<div class="colspan-2">
					<h5>Cereal $4</h5>
				</div>
				<div class="colspan-2">
					<h5>Milk $3</h5>
				</div>
				<div class="colspan-2">
					<h5>Eggs $2</h5>
				</div>
			</div>
		</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>