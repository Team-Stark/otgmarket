<?php $__env->startSection('title', 'Results'); ?>

<?php $__env->startSection('content'); ?>
		<h2 class="text-center" style="margin-top:50px; margin-bottom:50px;">Results</h2>
		<div class="grid">
			<div class="row" style="margin-bottom:30px;">
				<div class="colspan-2 offset-2">
					<a href="<?php echo e(route('item')); ?>">
						<div data-role="tile" data-size="medium" data-cover="lettuce.jpg"></div>
					</a>
				</div>
				<div class="colspan-2">
					<a href="<?php echo e(route('item')); ?>">
						<div data-role="tile" data-size="medium" data-cover="cereal.jpg"></div>
					</a>
				</div>
				<div class="colspan-2">
					<a href="<?php echo e(route('item')); ?>">
						<div data-role="tile" data-size="medium" data-cover="milk.jpg"></div>
					</a>
				</div>
				<div class="colspan-2">
					<a href="<?php echo e(route('item')); ?>">
						<div data-role="tile" data-size="medium" data-cover="eggs.jpg"></div>
					</a>
				</div>
			</div>
			<div class="row">
				<div class="colspan-2 offset-2">
					<h5>Lettuce $1.50</h5>
				</div>
				<div class="colspan-2">
					<h5>Cereal $4</h5>
				</div>
				<div class="colspan-2">
					<h5>Milk $3</h5>
				</div>
				<div class="colspan-2">
					<h5>Eggs $2</h5>
				</div>
			</div>
		</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>