@extends('admin.layout.admin')
@section('content')
    <h3>Employee</h3>
@endsection
