@extends('admin.layout.admin')

@section('content')

	<h3>Items</h3>

	<ul>
		@forelse($items as $item)
		<li>
			<h4>Name of item:{{$item}}</h4>
		</li>

		@empty

		<h3>No items</h3>

		@endforelse
	</ul>

@endsection