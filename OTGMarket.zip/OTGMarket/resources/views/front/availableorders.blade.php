@extends('layout.main')

@section('title', 'Available Orders')

@section('content')

        <h1 class="text-center" style="margin-top:50px; margin-bottom:50px;">Start delivering here.</h1>
        <div class="grid">
            <div class="row" style="margin-bottom:50px;">
                <div class="cell-3 offset-2">
                    <select data-role="select" data-prepend="Store: ">
                        <option>All</option>
                        <option>Publix</option>
                        <option>Walmart</option>
                        <option>Lucky's</option>
                    </select>
                </div>
                
            </div>
        </div>
        <!-- Need to make the images and names in these generate from something -->
        <h2 class="text-center" style="margin-bottom:50px;">Here are some available orders in your area.</h2>

        <?php 

        $resultCount = sizeof($products); //placeholder
        $counter = 0;
        $tileCount = 0;

        echo'<div class="grid">';

        while($counter < ceil($resultCount/4.0) && $tileCount < $resultCount) {
            
            echo '<div class="row" style="margin-bottom:30px;">';
            
            for($j = 0; $j < 4; $j++){

                //We'll put details from each order in the tiles
                if($tileCount < $resultCount){
                    if($j == 0){
                        echo '<div class="colspan-2 offset-2">
                        <div data-role="tile" data-size="medium" data-cover="lettuce.jpg">
                        </div>
                        </div>'; 

                    }else{
                        echo '<div class="colspan-2">
                        <div data-role="tile" data-size="medium" data-cover="lettuce.jpg">
                        </div>
                        </div>';
                        
                    }
                    $tileCount++;
                }

            }

            echo '</div>';
            $counter++;

        }

        echo '</div>'

        ?>
@endsection