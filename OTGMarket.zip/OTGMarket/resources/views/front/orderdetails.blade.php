@extends('layout.main')

@section('title', 'Order Details')

@section('content')

        <h1 class="text-center" style="margin-top:50px; margin-bottom:50px;">Order Details</h1>
        <div class="grid">
            <div class="row" style="margin-bottom:50px;">
                <?php 

                    $resultCount = sizeof($details[2]); 
                    echo "<h3>Delivering to $details[0] at $details[1]</h3>";
                    echo "<h4>Number of items: $resultCount</h4>";
                ?>
            </div>

            <button type="button">Accept Order</button>

        </div>
        <!-- Need to make the images and names in these generate from something -->

        <hr>

        <h2 class="text-center" style="margin-bottom:50px;">Here are some of the items in this order.</h2>

        <?php 

        $resultCount = sizeof($details[2]); //placeholder
        $counter = 0;
        $tileCount = 0;

        echo'<div class="grid">';

        while($counter < ceil($resultCount/4.0) && $tileCount < $resultCount) {
            
            echo '<div class="row" style="margin-bottom:30px;">';
            
            for($j = 0; $j < 4; $j++){

                //We'll put details from each order in the tiles
                if($tileCount < $resultCount){
                    if($j == 0){
                        echo '<div class="colspan-2 offset-2">
                        <div data-role="tile" data-size="medium" data-cover="lettuce.jpg">
                        </div>
                        </div>'; 

                    }else{
                        echo '<div class="colspan-2">
                        <div data-role="tile" data-size="medium" data-cover="lettuce.jpg">
                        </div>
                        </div>';
                        
                    }
                    $tileCount++;
                }

            }

            echo '</div>';
            $counter++;

        }

        echo '</div>'

        ?>

@endsection