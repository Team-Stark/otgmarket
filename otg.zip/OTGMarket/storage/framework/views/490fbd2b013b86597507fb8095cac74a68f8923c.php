<?php $__env->startSection('content'); ?>

	<h3>Cart Items</h3>
	<table class="table table-hover">
		<thead>
			<tr>
				<th>Name</th>
				<th>Price</th>
				<th>Quantity</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($cartItem->name); ?></td>
				<td><?php echo e($cartItem->price); ?></td>
				<td width="50px">
					<?php echo Form::open(['route' => ['cart.update',$cartItem->rowId], 'method' => 'put']); ?>

						<input name="quantity" type="text" value="<?php echo e($cartItem->quantity); ?>" width="30px">
						<input type="submit" class="btn btn-sm btn-default" value="Ok">
					<?php echo Form::close(); ?>

				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>