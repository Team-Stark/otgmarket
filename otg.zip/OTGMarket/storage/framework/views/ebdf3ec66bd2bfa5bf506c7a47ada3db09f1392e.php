<!DOCTYPE hmtl>
<html lang="en">
	<head>
		<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<title>
			<?php echo $__env->yieldContent('title', 'OTG Market'); ?>
		</title>
		<link rel="stylesheet" href="<?php echo e(asset('https://cdn.metroui.org.ua/v4/css/metro-all.min.css')); ?>"/>
	</head>
	<body>
		<?php echo $__env->yieldContent('content'); ?>
		<script src="<?php echo e(asset('https://code.jquery.com/jquery-3.3.1.min.js')); ?>"></script>
		<script src="<?php echo e(asset('https://cdn.metroui.org.ua/v4/js/metro.min.js')); ?>"></script>
	</body>
</html>