<?php $__env->startSection('content'); ?>

<h1>Settings will be added</h1>
<form method="POST" action="<?php echo e(url('test')); ?>">
	<?php echo csrf_field(); ?>
	<input type="text" id="name" name="name">
	<input type="submit">
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>