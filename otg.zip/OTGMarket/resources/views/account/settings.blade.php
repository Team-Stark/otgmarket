@extends('layout.main')

@section('content')

<h1>Settings will be added</h1>
<form method="POST" action="{{ url('test') }}">
	@csrf
	<input type="text" id="name" name="name">
	<input type="submit">
</form>

@endsection