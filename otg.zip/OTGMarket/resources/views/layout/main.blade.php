<!DOCTYPE hmtl>
<html lang="en">
	<head>
		@include('layout.head')
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<title>
			@yield('title', 'OTG Market')
		</title>
		<link rel="stylesheet" href="{{asset('https://cdn.metroui.org.ua/v4/css/metro-all.min.css')}}"/>
	</head>
	<body>
		@yield('content')
		<script src="{{asset('https://code.jquery.com/jquery-3.3.1.min.js')}}"></script>
		<script src="{{asset('https://cdn.metroui.org.ua/v4/js/metro.min.js')}}"></script>
	</body>
</html>