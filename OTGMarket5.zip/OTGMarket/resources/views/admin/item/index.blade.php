@extends('admin.layout.admin')

@section('content')

	<h3>Items</h3>

	<ul class="container">
		@forelse($items as $item)
		<li class="row">
			 <div class="col-md-8">
	        <h4>{{$item->name}} ${{$item->price}}</h4>
		</li>

		@empty

		<h3>No items</h3>

		@endforelse
	</ul>

@endsection