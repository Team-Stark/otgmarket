@extends('layout.main')

@section('content')

<div style="text-align: center; display: block; margin: auto;">
<form method="POST" action="{{ url('updatesettings') }}">
	@csrf
	<h2>Current Account Details</h2>
	<br>
	<b>Name:</b>
	<br>
	<i>{{ $user->name }}</i>
	<br>
	<b>Email:</b>
	<br>
	<i>{{ $user->email }}</i>
	<br>
	<b>Role:</b>
	<br>
	<i>{{ $user->role }}</i>
	<br>
	<br>
	<br>
	Name
	<input type="text" name="name" style="width: 30%; margin: 0 auto;">
	<br>
	Email
	<input type="email" name="email" style="width: 30%; margin: 0 auto;">
	<br>
	Role
	<select name="role" class="form-control" style="width: 30%; margin: 0 auto;">
    	<option value="admin">Admin</option>
        <option value="driver">Driver</option>
        <option value="customer">Customer</option>
    </select>
	<input type="submit">
</form>
</div>

@endsection