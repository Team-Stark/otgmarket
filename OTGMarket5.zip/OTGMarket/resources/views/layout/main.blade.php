<!DOCTYPE hmtl>
<html lang="en">
	<head>
		@include('layout.head')
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<title>
			@yield('title', 'OTG Market')
		</title>
		<link rel="stylesheet" href="{{asset('https://cdn.metroui.org.ua/v4/css/metro-all.min.css')}}"/>		<script src="https://js.stripe.com/v3/"></script>
	</head>
	<body>
		@yield('content')
		<hr>
			<h6 class="text-center" style="margin-bottom:20px;"><a href="{{url('/contact') }}">Contact Us</a></h6>
		<script src="{{asset('https://code.jquery.com/jquery-3.3.1.min.js')}}"></script>
		<script src="{{asset('https://cdn.metroui.org.ua/v4/js/metro.min.js')}}"></script>
	</body>
</html>