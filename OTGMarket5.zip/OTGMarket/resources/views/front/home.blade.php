@extends('layout.main')

@section('content')

<h1 class="text-center" style="margin-top:50px; margin-bottom:50px;">What item are you looking for?</h1>
		<div class="grid" style="margin-bottom:300px">
			<div class="row" style="margin-bottom:50px;">
				<div class="cell-5 offset-3" style="margin-left:500px; margin-top:50px">
					<form action="{{route('results')}}" method="get" class="form-inline">
				      <div class="form-group">
				        <input type="text" class="form-control" name="s" placeholder="Item">
				      </div>
				      <div class="form-group">
				        <button class="btn btn-success" type="submit">Search</button>
				      </div>
				    </form>
				</div>
			</div>
		</div>
<!--		<div class="grid">
			<div class="row" style="margin-bottom:30px;">
				<div class="colspan-2 offset-2">
					<a href="{{route('item')}}">
						<div data-role="tile" data-size="medium" data-cover="lettuce.jpg"></div>
					</a>
				</div>
				<div class="colspan-2">
					<a href="{{route('item')}}">
						<div data-role="tile" data-size="medium" data-cover="cereal.jpg"></div>
					</a>
				</div>
				<div class="colspan-2">
					<a href="{{route('item')}}">
						<div data-role="tile" data-size="medium" data-cover="milk.jpg"></div>
					</a>
				</div>
				<div class="colspan-2">
					<a href="{{route('item')}}">
						<div data-role="tile" data-size="medium" data-cover="eggs.jpg"></div>
					</a>
				</div>
			</div>
			<div class="row" style="margin-bottom:50px;">
				<div class="colspan-2 offset-2">
					<h5>Lettuce $1.50</h5>
				</div>
				<div class="colspan-2">
					<h5>Cereal $4</h5>
				</div>
				<div class="colspan-2">
					<h5>Milk $3</h5>
				</div>
				<div class="colspan-2">
					<h5>Publix Large Eggs 6-Count $2</h5>
				</div>
			</div>
		</div>
		<h2 class="text-center" style="margin-bottom:30px;">Recently Bought</h2>
		<div class="grid">
			<div class="row" style="margin-bottom:30px;">
				<div class="colspan-2 offset-2">
					<a href="{{route('item')}}">
						<div data-role="tile" data-size="medium" data-cover="lettuce.jpg"></div>
					</a>
				</div>
				<div class="colspan-2">
					<a href="{{route('item')}}">
						<div data-role="tile" data-size="medium" data-cover="cereal.jpg"></div>
					</a>
				</div>
				<div class="colspan-2">
					<a href="{{route('item')}}">
						<div data-role="tile" data-size="medium" data-cover="milk.jpg"></div>
					</a>
				</div>
				<div class="colspan-2">
					<a href="{{route('item')}}">
						<div data-role="tile" data-size="medium" data-cover="eggs.jpg"></div>
					</a>
				</div>
			</div>
			<div class="row" style="margin-bottom:50px;">
				<div class="colspan-2 offset-2">
					<h5>Lettuce $1.50</h5>
				</div>
				<div class="colspan-2">
					<h5>Cereal $4</h5>
				</div>
				<div class="colspan-2">
					<h5>Milk $3</h5>
				</div>
				<div class="colspan-2">
					<h5>Eggs $2</h5>
				</div>
			</div>
		</div>
-->
@endsection