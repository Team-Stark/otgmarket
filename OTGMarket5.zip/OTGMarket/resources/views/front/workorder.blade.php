@extends('layout.main')

@section('title', 'Current Order')

@section('content')

<h1 style="margin-left:780px">Order:</h1>
<br>
<table style="margin-left:720px">
	<tr style="margin-top:15px">
		<th>Item</th>
	</tr>
	<tr style="margin-top:30px">
<form action="{{route('itemupdate', [$orderID]) }}" method="get">
	@foreach($orderitems as $item)
	<td>{{ $item->name }}</td> <td><img src="{{ $item->image }}"></td> <td><input type="checkbox" name="itemPurchased[]" value="{{ $item->id }}" {{$item->pivot->added==1?"checked":""}}></td>
	</tr>
	@endforeach
</table>
	<button  style="margin-left:785px; margin-top:30px; margin-bottom:50px" type="submit">Order complete?</button>
</form>

@endsection