@extends('layout.main')

@section('content')

    <table style="margin-left:400px; margin-top:100px">
        <tr>
            <th></th>
        </tr>
        @foreach($orders as $order)
        <tr>
            <td>
                <a href="#" style="margin-left:365px">Items in Order</a>
            </td>
            <td>
                <form method="get" action="{{ route('updateavailable') }}">
                    <button name="order" type="submit" value="{{ $order->id }}">Accept Order</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>

@endsection