@extends('layout.main')

@section('content')

	<h3>Delivery Info</h3>

	{!! Form::open(['route' => 'address.store', 'method' => 'post']) !!}

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		{{ Form::label('addressline', 'Address Line') }}
		{{ Form::text('addressline', null, array('class' => 'form-control')) }}
	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		{{ Form::label('city', 'City') }}
		{{ Form::text('city', null, array('class' => 'form-control')) }}
	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		{{ Form::label('state', 'State') }}
		{{ Form::text('state', null, array('class' => 'form-control')) }}
	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		{{ Form::label('zip', 'Zip') }}
		{{ Form::text('zip', null, array('class' => 'form-control')) }}
	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		{{ Form::label('country', 'Country') }}
		{{ Form::text('country', null, array('class' => 'form-control')) }}
	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		{{ Form::label('phone', 'Phone') }}
		{{ Form::text('phone', null, array('class' => 'form-control')) }}
	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		{{ Form::label('cardnumber', 'Card Number') }}
		{{ Form::text('cardnumber', null, array('class' => 'form-control')) }}
	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		{{ Form::label('expiration', 'Expiration (mm/yy)') }}
		{{ Form::text('expiration', null, array('class' => 'form-control')) }}
	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		{{ Form::label('cvv', 'CVV') }}
		{{ Form::text('cvv', null, array('class' => 'form-control')) }}
	</div>

	{{ Form::submit('Submit Order', array('class' => 'button success')) }}
	{!! Form::close() !!}

@endsection