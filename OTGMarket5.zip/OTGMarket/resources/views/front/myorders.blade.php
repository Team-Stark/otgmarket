@extends('layout.main')

@section('title', 'Your Orders')

@section('content')

<style>
table {  
    color: #333;
    font-family: Helvetica, Arial, sans-serif;
    width: 1200px; 
    border-collapse: 
    collapse; border-spacing: 0; 
    margin-left:auto;
    margin-right:auto;
}

td, th {  
    border: 1px solid transparent; /* No more visible border */
    height: 30px; 
    transition: all 0.3s;  /* Simple transition for hover effect */
}

th {  
    background-color: #4C6CA0;
    color: white;
    font-weight: bold;
}

td {  
    background: #FAFAFA;
    text-align: center;
}

/* Cells in even rows (2,4,6...) are one color */        
tr:nth-child(even) td { background: #F1F1F1; }   

/* Cells in odd rows (1,3,5...) are another (excludes header cells)  */        
tr:nth-child(odd) td { background: #FEFEFE; }  

</style>



<h1 class="text-center" style="margin-top:50px; margin-bottom:20px;"> Your Orders </h1>
<h6 class="text-center" style="margin-bottom:80px;">Here are all of your orders, past and present.</h6>
	

<table>
<tr>
	<th>Order ID</th>
    <th>Date Ordered</th>
    <th>Price</th>
    <th>Status</th>
</tr>
@foreach($orders as $order)
<tr>
	<td>{{$order->id}}</td>
    <td>{{$order->created_at}}</td>
    <td>${{number_format($order->total, 2, '.', '')}}</td>
    @if($order->delivered == 1)
        <td>Delivered</td>
    @elseif($order->in_progress == 1)
        <td>In Progress</td>
    @else
        <td>Pending</td>
    @endif
</tr>
@endforeach

@endsection