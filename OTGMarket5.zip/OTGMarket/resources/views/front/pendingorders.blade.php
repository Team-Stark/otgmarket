@extends('layout.main')

@section('title', 'Your Work Orders')

@section('content')

	@foreach($inprogress as $order)
	<a href="{{ route('/workorder', [$order->id]) }}">{{ $order->id }}</a>
	<br>
	@endforeach

@endsection