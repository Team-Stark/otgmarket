<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'FrontController@index')->name('home');

Route::get('/results', 'FrontController@results')->name('results');

Route::get('/item', 'FrontController@item')->name('item');

Route::get('/availableorders', 'FrontController@availableorders')->name('availableorders');

Route::get('/orderdetails', 'FrontController@orderdetails')->name('orderdetails');

Auth::routes();

Route::get('/logout', 'Auth\LoginController@logout');

Route::get('/home', 'HomeController@index');

Route::resource('/cart', 'CartController');

Route::group(['prefix' => 'admin','middleware' => ['auth','admin']], function() {

	Route::post('toggledeliver/{orderId}', 'OrderController@toggledeliver')->name('toggle.deliver');

	Route::get('/', function() {
		return view('admin.index');
	})->name('admin.index');

	Route::resource('item', 'ItemsController');

	Route::get('orders/{type?}', 'OrderController@Orders');
});

Route::group(['middleware' => 'auth'], function () {
	Route::get('shipping-info', 'CheckoutController@shipping')->name('checkout.shipping');
});

Route::get('/myorders', 'FrontController@myorders')->name('myorders');

Route::get('/orderlist', 'FrontController@orderlist')->name('orderlist');

Route::resource('address', 'AddressController');

Route::get('/settings', 'FrontController@settings'); 

Route::post('updatesettings', 'FrontController@updatesettings');    

Route::get('/customer', 'FrontController@index')->middleware('auth', 'customer');

Route::get('/driver', 'DeliveryController@workorder')->middleware('auth', 'driver');

Route::get('/availableorders', 'DeliveryController@availableorders')->middleware('auth', 'driver');

Route::get('updateavailable', 'DeliveryController@updateavailable')->name('updateavailable');

Route::get('/orders', 'DeliveryController@orders')->middleware('auth', 'driver');

Route::get('/workorder/{order}', 'DeliveryController@workorder')->middleware('auth', 'driver')->name('/workorder');

Route::get('itemupdate{order}', 'DeliveryController@ItemUpdate')->name('itemupdate');

Route::get('/contact', 'FrontController@contact')->name('contact');

