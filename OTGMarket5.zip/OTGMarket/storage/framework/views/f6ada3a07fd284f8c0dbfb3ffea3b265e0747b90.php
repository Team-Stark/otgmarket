<?php $__env->startSection('content'); ?>

	<h3>Items</h3>

	<ul class="container">
		<?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<li class="row">
			 <div class="col-md-8">
	        <h4><?php echo e($item->name); ?> $<?php echo e($item->price); ?></h4>
		</li>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

		<h3>No items</h3>

		<?php endif; ?>
	</ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>