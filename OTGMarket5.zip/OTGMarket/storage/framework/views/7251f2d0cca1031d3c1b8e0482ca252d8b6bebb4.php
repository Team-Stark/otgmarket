<?php $__env->startSection('title', 'Current Order'); ?>

<?php $__env->startSection('content'); ?>

<h1 style="margin-left:780px">Order:</h1>
<br>
<table style="margin-left:720px">
	<tr style="margin-top:15px">
		<th>Item</th>
	</tr>
	<tr style="margin-top:30px">
<form action="<?php echo e(route('itemupdate', [$orderID])); ?>" method="get">
	<?php $__currentLoopData = $orderitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<td><?php echo e($item->name); ?></td> <td><img src="<?php echo e($item->image); ?>"></td> <td><input type="checkbox" name="itemPurchased[]" value="<?php echo e($item->id); ?>" <?php echo e($item->pivot->added==1?"checked":""); ?>></td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
	<button  style="margin-left:785px; margin-top:30px; margin-bottom:50px" type="submit">Order complete?</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>