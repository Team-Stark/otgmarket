<?php $__env->startSection('title', 'Current Order'); ?>

<?php $__env->startSection('content'); ?>

<style>
/* The container */
.container {
    display: block;
    position: relative;
    padding-left: 35px;
    margin-bottom: 12px;
    cursor: pointer;
    font-size: 22px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}

/* Hide the browser's default checkbox */
.container input {
    position: absolute;
    opacity: 0;
    cursor: pointer;
    height: 0;
    width: 0;
}

/* Create a custom checkbox */
.checkmark {
    position: absolute;
    top: 0;
    left: 0;
    height: 25px;
    width: 25px;
    background-color: #eee;
}

/* On mouse-over, add a grey background color */
.container:hover input ~ .checkmark {
    background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.container input:checked ~ .checkmark {
    background-color: #2196F3;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
    content: "";
    position: absolute;
    display: none;
}

/* Show the checkmark when checked */
.container input:checked ~ .checkmark:after {
    display: block;
}

/* Style the checkmark/indicator */
.container .checkmark:after {
    left: 9px;
    top: 5px;
    width: 5px;
    height: 10px;
    border: solid white;
    border-width: 0 3px 3px 0;
    -webkit-transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    transform: rotate(45deg);
}
</style>

<h1 class="text-center" style="margin-top:50px; margin-bottom:50px;"> Order Items </h1>

<?php

echo '<h2 class="text-center">';
echo $products[0][0];
echo 's Order</h2>';
echo '<h2 class="text-center" style="margin-bottom:50px;">';
echo $products[0][1];
echo '</h2>';

 $resultCount = sizeof($products) - 1; //placeholder
 $counter = 1;

        while($counter <= $resultCount) {    

            echo '<label class="container">';
            echo $products[$counter];
            echo'<input type="checkbox">
                <span class="checkmark"></span>
                </label>';

            $counter+=1;
        }

?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>