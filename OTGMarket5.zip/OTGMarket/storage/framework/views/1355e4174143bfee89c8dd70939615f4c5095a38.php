<?php $__env->startSection('content'); ?>

    <table style="margin-left:400px; margin-top:100px">
        <tr>
            <th></th>
        </tr>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <a href="#" style="margin-left:365px">Items in Order</a>
            </td>
            <td>
                <form method="get" action="<?php echo e(route('updateavailable')); ?>">
                    <button name="order" type="submit" value="<?php echo e($order->id); ?>">Accept Order</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>