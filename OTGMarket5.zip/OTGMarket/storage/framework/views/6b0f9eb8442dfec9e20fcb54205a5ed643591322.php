<?php $__env->startSection('content'); ?>

<div style="text-align: center; display: block; margin: auto;">
<form method="POST" action="<?php echo e(url('updatesettings')); ?>">
	<?php echo csrf_field(); ?>
	<h2>Current Account Details</h2>
	<br>
	<b>Name:</b>
	<br>
	<i><?php echo e($user->name); ?></i>
	<br>
	<b>Email:</b>
	<br>
	<i><?php echo e($user->email); ?></i>
	<br>
	<b>Role:</b>
	<br>
	<i><?php echo e($user->role); ?></i>
	<br>
	<br>
	<br>
	Name
	<input type="text" name="name" style="width: 30%; margin: 0 auto;">
	<br>
	Email
	<input type="email" name="email" style="width: 30%; margin: 0 auto;">
	<br>
	Role
	<select name="role" class="form-control" style="width: 30%; margin: 0 auto;">
    	<option value="admin">Admin</option>
        <option value="driver">Driver</option>
        <option value="customer">Customer</option>
    </select>
	<input type="submit">
</form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>