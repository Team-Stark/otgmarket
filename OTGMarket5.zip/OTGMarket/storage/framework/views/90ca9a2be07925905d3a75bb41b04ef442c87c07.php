<?php $__env->startSection('content'); ?>

	<h3>Delivery Info</h3>

	<?php echo Form::open(['route' => 'address.store', 'method' => 'post']); ?>


	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		<?php echo e(Form::label('addressline', 'Address Line')); ?>

		<?php echo e(Form::text('addressline', null, array('class' => 'form-control'))); ?>

	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		<?php echo e(Form::label('city', 'City')); ?>

		<?php echo e(Form::text('city', null, array('class' => 'form-control'))); ?>

	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		<?php echo e(Form::label('state', 'State')); ?>

		<?php echo e(Form::text('state', null, array('class' => 'form-control'))); ?>

	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		<?php echo e(Form::label('zip', 'Zip')); ?>

		<?php echo e(Form::text('zip', null, array('class' => 'form-control'))); ?>

	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		<?php echo e(Form::label('country', 'Country')); ?>

		<?php echo e(Form::text('country', null, array('class' => 'form-control'))); ?>

	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		<?php echo e(Form::label('phone', 'Phone')); ?>

		<?php echo e(Form::text('phone', null, array('class' => 'form-control'))); ?>

	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		<?php echo e(Form::label('cardnumber', 'Card Number')); ?>

		<?php echo e(Form::text('cardnumber', null, array('class' => 'form-control'))); ?>

	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		<?php echo e(Form::label('expiration', 'Expiration (mm/yy)')); ?>

		<?php echo e(Form::text('expiration', null, array('class' => 'form-control'))); ?>

	</div>

	<div class="form-group" style="margin-left:200px; margin-right:200px;">
		<?php echo e(Form::label('cvv', 'CVV')); ?>

		<?php echo e(Form::text('cvv', null, array('class' => 'form-control'))); ?>

	</div>

	<?php echo e(Form::submit('Submit Order', array('class' => 'button success'))); ?>

	<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>