<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Item extends Model
{
    protected $fillable=['name', 'description', 'image','price','store'];

    public function scopeSearch($query, $s)
  {
    return $query->where('name', 'like', '%' .$s. '%')
    	->orWhere('description', 'like', '%' .$s. '%');
  }
}
