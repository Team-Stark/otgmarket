<!DOCTYPE html>
<html>
<body>
	<table>
		<tr>
			<th>Stores</th>
			<th>Items</th>
			<th></th>
		</tr>
		<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td>
				Publix
			</td>
			<td>
				<a href="#">Items in Order</a>
			</td>
			<td>
				<form method="get" action="<?php echo e(route('updateavailable')); ?>">
					<button name="order" type="submit" value="<?php echo e($order->id); ?>">Accept Order</button>
				</form>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
</body>
</html>