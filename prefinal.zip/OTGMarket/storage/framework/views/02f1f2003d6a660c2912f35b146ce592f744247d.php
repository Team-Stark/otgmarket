<!DOCTYPE html>
<html>
<body>
	<?php $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<a href="<?php echo e(route('/workorder', [$order->id])); ?>"><?php echo e($order->id); ?></a>
	<br>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>