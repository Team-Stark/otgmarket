<style>
/* Style the header with a grey background and some padding */
.header {
  overflow: hidden;
  background-color: #cfd2d6;
  padding: 15px 10px;
  border-radius: 4px;
}

/* Style the header links */
.header a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-family: 'Open Sans', sans-serif; ;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;
}

/* Style the logo link (notice that we set the same value of line-height and font-size to prevent the header to increase when the font gets bigger */
.header a.logo {
  font-size: 25px;
  font-weight: bold;
}

/* Change the background color on mouse-over */
.header a:hover {
  background-color: #ddd;
  color: black;
}

/* Style the active/current link*/
.header a.headbtn {
  background-color: dodgerblue;
  color: white;
}

.header a.headbtn:hover {
  background-color: #dfd;
  color: black;
}


/* Float the link section to the right */
.header-right {
  float: right;
}

.header-right a + a{
  margin-left: 6px;
}

.header-right a + input{
  margin-left: 12px;
}

.header-right .search-container input + button{
  margin-left: 0px;
}

.header-right .search-container {
  float: left;
  margin-left: 20px;
}

.header-right .search-container input[type=text] {
    float: none;
    padding: 6px;
    border: none;
    margin-top: 8px;
    margin-right: 2px;
    font-size: 17px;
}

.header-right .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.header-right .search-container button:hover {
  background: #ccc;
}

/* Add media queries for responsiveness - when the screen is 500px wide or less, stack the links on top of each other */ 
@media  screen and (max-width: 500px) {
  .header a {
    float: none;
    display: block;
    text-align: left;
  }
  .header-right {
    float: none;
  }

</style>
<link rel="stylesheet" type="text/css" href="styles.css" media="screen" />

<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<div class="header">
  <a href="#default" class="logo">OTG Market</a>

  <div class="header-center">
  </div>

  <div class="header-right">
  	<div class="search-container">
      <form method="GET">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>  
      </form> 
  	</div>
    <a class="headbtn" href="#orders">My Orders</a>
    <a class="headbtn" href="#cart">My Cart</a>
    <a class ="headbtn" href="#settings">Settings</a>
  </div>
</div>