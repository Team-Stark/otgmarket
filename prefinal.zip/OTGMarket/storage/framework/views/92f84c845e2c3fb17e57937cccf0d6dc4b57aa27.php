<!DOCTYPE html>
<html>
<body>
<h1>Orders are:</h1>
<br>
<table>
	<tr>
		<th>Store</th>
		<th>Item</th>
		<th></th>
		<th></th>
	</tr>
<form action="<?php echo e(route('itemupdate', [$orderID])); ?>" method="get">
	<tr>
	<?php $__currentLoopData = $orderitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<td><?php echo e($item->store); ?></td> <td><?php echo e($item->name); ?></td> <td><img src="<?php echo e($item->image); ?>"></td> <td><input type="checkbox" name="itemPurchased[]" value="<?php echo e($item->id); ?>" <?php echo e($item->completed==1?"checked":""); ?>></td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
	<button type="submit">Order complete?</button>
</form>
</body>
</html>