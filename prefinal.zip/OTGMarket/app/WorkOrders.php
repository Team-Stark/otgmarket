<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WorkOrders extends Model
{
    protected $fillable = [
    	'id', 'order', 'store', 'name', 'image', 'completed'
    ];

    public function order()
    {
    	return $this->belongsTo('App\Orders', 'id');
    }
}
