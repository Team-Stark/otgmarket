<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Orders extends Model
{
    protected $fillable = [
    	'id', 'accepted', 'driver',
    ];

    public function workorder()
    {
    	return $this->hasMany('App\WorkOrders', 'id', 'order');
    }
}
