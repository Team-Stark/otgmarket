<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\WorkOrders;
use App\Orders;
use Auth;

class DeliveryController extends Controller
{
	public function workorder($orderID)
	{
		$orderitems = WorkOrders::where('order', $orderID)->get();
		return view('driver.workorder')->with('orderitems', $orderitems)->with('orderID', $orderID);
	}

	public function ItemUpdate(Request $request, $orderID)
	{
		$itemPurchased = $request->input('itemPurchased');
		$allItems = true;
		foreach($itemPurchased as $check)
		{
			WorkOrders::where('id', $check)->update(['completed' => 1]);
		}

		if(WorkOrders::where('order', $orderID)->where('completed', 0)->exists())
			$allItems = false;

		if($allItems)
			return redirect('/');
		else
			return back();
	}

	public function availableorders()
	{
		$orders = Orders::where('accepted', 0)->get();
		return view('driver.availableorders')->with('orders', $orders);
	}

	public function updateavailable(Request $request)
	{
		$accepted = $request->input('order');
		Orders::where('id', $accepted)->update(['accepted' => 1, 'driver' => Auth::id()]);
		WorkOrders::create(['order' => $accepted, 'store' => "Publix"]);
		return back();
	}

	public function orders()
	{
		$pending = Orders::where('driver', Auth::id())->get();
		return view('driver.pendingorders')->with('pending', $pending);
	}
}
