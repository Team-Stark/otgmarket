<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Item;
use Auth;

class FrontController extends Controller
{
    public function index()
    {
    	return view('front.home');
    }

    public function results()
    {
      $items=Item::all();
    	return view('front.results', compact('items'));
    }

    public function item()
    {
    	return view('front.item');
    }

    public function availableorders()
   {
       $products = [ 'Bread', 'Milk', 'Eggs' ];
       return view('front.availableorders')->withProducts($products);
   }

   public function orderdetails()
   {
        $products = ['Bread', 'Milk', 'Eggs'];
        $details = ['John Doe','1234 Main Street, Tallahassee, Fl, 32301', $products];
        
        if(Auth::check())
          return view('front.orderdetails')->withDetails($details);
        else
          return redirect('/login');
   }

   public function settings()
   {
      if(Auth::check())
      {
        $user = Auth::user();
        return view('account.settings', ["user" => $user]);
      }
      else
        return redirect('/login');
   }

   public function test(Request $request)
   {
    $name = $request->input('name');
    return view('test', ["name" => $name]);
   }

   public function updatesettings(Request $request)
   {
    $validatedData = $request->validate([
      'name' => ['required', 'string', 'max:255'],
      'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
      'role' => 'required|in:admin,driver,customer'
    ]);
    $user = Auth::user();
    $user->name = $request->input('name');
    $user->email = $request->input('email');
    $user->role = $request->input('role');
    $user->save();
    return redirect('settings');
   }
}
