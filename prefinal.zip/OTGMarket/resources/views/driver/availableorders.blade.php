<!DOCTYPE html>
<html>
<body>
	<table>
		<tr>
			<th>Stores</th>
			<th>Items</th>
			<th></th>
		</tr>
		@foreach($orders as $order)
		<tr>
			<td>
				Publix
			</td>
			<td>
				<a href="#">Items in Order</a>
			</td>
			<td>
				<form method="get" action="{{ route('updateavailable') }}">
					<button name="order" type="submit" value="{{ $order->id }}">Accept Order</button>
				</form>
			</td>
		</tr>
		@endforeach
	</table>
</body>
</html>