<!DOCTYPE html>
<html>
<body>
	@foreach($pending as $order)
	<a href="{{ route('/workorder', [$order->id]) }}">{{ $order->id }}</a>
	<br>
	@endforeach
</body>