<!DOCTYPE html>
<html>
<body>
<h1>Orders are:</h1>
<br>
<table>
	<tr>
		<th>Store</th>
		<th>Item</th>
		<th></th>
		<th></th>
	</tr>
<form action="{{ route('itemupdate', [$orderID]) }}" method="get">
	<tr>
	@foreach($orderitems as $item)
	<td>{{ $item->store }}</td> <td>{{ $item->name }}</td> <td><img src="{{ $item->image }}"></td> <td><input type="checkbox" name="itemPurchased[]" value="{{ $item->id }}" {{$item->completed==1?"checked":""}}></td>
	</tr>
	@endforeach
</table>
	<button type="submit">Order complete?</button>
</form>
</body>
</html>