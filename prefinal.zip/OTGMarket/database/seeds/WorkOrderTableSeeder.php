<?php

use Illuminate\Database\Seeder;

class WorkOrderTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('work_orders')->insert([
        	'order' => 10,
        	'store' => str_random(10),
        	'name' => str_random(10),
        ]);
    }
}
