<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'FrontController@index')->name('home');

Route::get('/results', 'FrontController@results')->name('results');

Route::get('/item', 'FrontController@item')->name('item');

Route::get('/availableorders', 'FrontController@availableorders')->name('availableorders');

Route::get('/orderdetails', 'FrontController@orderdetails')->name('orderdetails');

Auth::routes();

Route::get('/logout', 'Auth\LoginController@logout');

Route::get('/home', 'HomeController@index');

Route::resource('/cart', 'CartController');

Route::group(['prefix' => 'admin','middleware' => 'auth'], function() {
	Route::get('/', function() {
		return view('admin.index');
	})->name('admin.index');

Route::resource('item', 'ItemsController');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/admin', function(){
	return view('admin');
})->middleware('auth', 'admin');

Route::get('/driver', function(){
	return view('availableorders');
})->middleware('auth', 'driver');

Route::get('/customer', 'FrontController@index')->middleware('auth', 'customer');