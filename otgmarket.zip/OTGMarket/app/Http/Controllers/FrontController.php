<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Item;

class FrontController extends Controller
{
    public function index()
    {
    	return view('front.home');
    }

    public function results()
    {
      $items=Item::all();
    	return view('front.results', compact('items'));
    }

    public function item()
    {
    	return view('front.item');
    }

    public function availableorders()
   {
       $products = [ 'Bread', 'Milk', 'Eggs' ];
       return view('front.availableorders')->withProducts($products);
   }

   public function orderdetails()
   {
        $products = ['Bread', 'Milk', 'Eggs'];
        $details = ['John Doe','1234 Main Street, Tallahassee, Fl, 32301', $products];
        
        return view('front.orderdetails')->withDetails($details);
   }
}
